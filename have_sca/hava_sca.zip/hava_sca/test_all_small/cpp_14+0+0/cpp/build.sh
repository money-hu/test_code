#!/bin/bash
cd cpp
gcc  vuln.c -o vuln