using System;
using System.Diagnostics;

namespace coredemo2._2.Models{
    public class Userinfo{
        public string Name { get; set; }
        public String Age { get; set; }
        public string Password { get; set; }

        public String bz{ get;set;}

    }

}